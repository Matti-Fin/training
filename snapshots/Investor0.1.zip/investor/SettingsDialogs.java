package investor;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class SettingsDialogs {

    public static class SetupResult {
        public final List<Player> players;
        public SetupResult(List<Player> players) { this.players = players; }
    }

    public static SetupResult showSetupDialog(JFrame parent, GameState state) {
        // Värit (sun lista)
        List<ColorChoice> colors = new ArrayList<>(Arrays.asList(
                new ColorChoice("#00FF00"),
                new ColorChoice("#00FFFF"),
                new ColorChoice("#000000"),
                new ColorChoice("#FFFF00"),
                new ColorChoice("#FF0000"),
                new ColorChoice("#FF00FF"),
                new ColorChoice("#FFFFFF"),
                new ColorChoice("#000080"),
                new ColorChoice("#0000FF"),
                new ColorChoice("#008000"),
                new ColorChoice("#808080")
        ));

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6,6,6,6);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1.0;

        SpinnerNumberModel playersModel = new SpinnerNumberModel(2, 2, 10, 1);
        JSpinner playersSpin = new JSpinner(playersModel);

        JTextField startCash = new JTextField("" + state.cfg.startCash, 12);

        gc.gridx = 0; gc.gridy = 0; panel.add(new JLabel("Players (2-10)"), gc);
        gc.gridx = 1; panel.add(playersSpin, gc);

        gc.gridx = 0; gc.gridy = 1; panel.add(new JLabel("Start cash ($)"), gc);
        gc.gridx = 1; panel.add(startCash, gc);

        int ok = JOptionPane.showConfirmDialog(parent, panel, "Investor setup", JOptionPane.OK_CANCEL_OPTION);
        if (ok != JOptionPane.OK_OPTION) return null;

        int n = (Integer) playersSpin.getValue();
        long sc;
        try { sc = Long.parseLong(startCash.getText().trim().replace("_","")); }
        catch (Exception ex) { sc = state.cfg.startCash; }

        state.cfg.startCash = sc;

        // Players: kysy nimi + väri per pelaaja
        List<Player> pls = new ArrayList<>();
        List<ColorChoice> available = new ArrayList<>(colors);

        for (int i = 0; i < n; i++) {
            Player p = askPlayer(parent, i + 1, available, sc);
            if (p == null) return null;
            pls.add(p);
            // poista valittu väri listasta
            available.removeIf(cc -> cc.color.equals(p.color));

        }

        return new SetupResult(pls);
    }

    private static Player askPlayer(JFrame parent, int num, List<ColorChoice> available, long startCash) {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gc = new GridBagConstraints();
        gc.insets = new Insets(6,6,6,6);
        gc.anchor = GridBagConstraints.WEST;
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.weightx = 1.0;

        JTextField name = new JTextField("Player " + num, 14);

        JComboBox<ColorChoice> colorBox = new JComboBox<>(available.toArray(new ColorChoice[0]));
        colorBox.setRenderer(new ColorChoiceRenderer());

        gc.gridx = 0; gc.gridy = 0; panel.add(new JLabel("Name"), gc);
        gc.gridx = 1; panel.add(name, gc);

        gc.gridx = 0; gc.gridy = 1; panel.add(new JLabel("Color"), gc);
        gc.gridx = 1; panel.add(colorBox, gc);

        int ok = JOptionPane.showConfirmDialog(parent, panel, "Player " + num, JOptionPane.OK_CANCEL_OPTION);
        if (ok != JOptionPane.OK_OPTION) return null;

        ColorChoice cc = (ColorChoice) colorBox.getSelectedItem();
        if (cc == null) return null;

        Player p = new Player(name.getText().trim(), cc.color, startCash);
        p.cash = startCash;
        return p;
    }

    static class ColorChoice {
        final String hex;
        final Color color;
        ColorChoice(String hex) {
            this.hex = hex;
            this.color = Color.decode(hex);
        }
        @Override public String toString() { return hex; }
    }

    static class ColorChoiceRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            JLabel lbl = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof ColorChoice cc) {
                lbl.setText(cc.hex);
                lbl.setIcon(makeIcon(cc.color));
            }
            return lbl;
        }

        private Icon makeIcon(Color c) {
            return new Icon() {
                @Override public void paintIcon(Component comp, Graphics g, int x, int y) {
                    g.setColor(c);
                    g.fillRect(x, y, getIconWidth(), getIconHeight());
                    g.setColor(Color.DARK_GRAY);
                    g.drawRect(x, y, getIconWidth()-1, getIconHeight()-1);
                }
                @Override public int getIconWidth() { return 18; }
                @Override public int getIconHeight() { return 12; }
            };
        }
    }

    private SettingsDialogs() {}
}
