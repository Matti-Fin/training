package investor;

import javax.swing.*;

public class TurnLogic {

    public static void startTurn(GameState state) {
        state._investmentsThisTurn = 0;
        state._nightsThisTurn = 0;
    }

    public static void movePlayerAnimated(GameState state, int steps, Runnable onDone) {
        Player pl = state.currentPlayer();
        state.isBusy = true;
        if (state.rollBtn != null) state.rollBtn.setEnabled(false);

        final int[] left = {steps};

        Timer t = new Timer(250, null); // 0.25s per square
        t.addActionListener(e -> {
            if (left[0] <= 0) {
                t.stop();
                state.isBusy = false;
                if (state.rollBtn != null) state.rollBtn.setEnabled(true);

                // land
                Square sq = state.path.get(pl.posId);
                Finance.onLand(state, sq);

                if (onDone != null) onDone.run();
                return;
            }

            // step forward
            int next = (pl.posId + 1) % state.path.size();
            pl.posId = next;
            left[0]--;

            // footsteps SFX per step (throttled)
            if (state.soundOn && state.cfg != null && state.cfg.sfxFootsteps != null) {
                long now = System.currentTimeMillis();
                if (now - state._lastFootstepMs >= 180) { // max ~5-6 per second
                    state._lastFootstepMs = now;
                    Audio.playExclusive("footsteps", state.cfg.sfxFootsteps, 0.35f);
                }
            }

            // passing checkpoint actions when stepping onto it
            Square sq = state.path.get(pl.posId);
            if (sq.type == SquareType.CHECKPOINT_THIN) {
                applyCheckpointRules(state, pl);
            }

            if (state.boardPanel != null) state.boardPanel.repaint();
        });

        t.start();
    }

    private static void applyCheckpointRules(GameState state, Player pl) {
        long nw = pl.netWorth();

        // KELA support
        if (nw < state.cfg.kelaWealthThreshold) {
            pl.cash += state.cfg.kelaSupportPerRound;
            pl.roundEarnings += state.cfg.kelaSupportPerRound;
            if (state.infoLabel != null) {
                state.infoLabel.setText("KELA: +" + state.cfg.kelaSupportPerRound + " (net worth < " + state.cfg.kelaWealthThreshold + ")");
            }
        }

        // Verottaja: if earned > 10k, pay 30%
        if (pl.roundEarnings > 10_000) {
            long tax = Math.round(pl.roundEarnings * 0.30);
            pl.cash = Math.max(0, pl.cash - tax);
            if (state.infoLabel != null) state.infoLabel.setText("Verottaja: -" + tax + " (30% of round earnings)");
        }

        // reset round earnings after checkpoint
        pl.roundEarnings = 0;
    }

    public static void endTurn(GameState state) {
        // roll over nights + population tick
        for (Property p : state.allProperties) {
            p.rolloverRoundNights();
            p.onRoundTick(state);
        }

        // casino risk decay
        Player pl = state.currentPlayer();
        pl.casinoRiskExtraPct = Math.max(0, pl.casinoRiskExtraPct - 1);

        // FED update based on last 10 turns
        Market.recordTurn(state, state._investmentsThisTurn, state._nightsThisTurn);

        if (state.fedRateJustChanged && state.infoLabel != null) {
            state.infoLabel.setText(String.format("FED changed -> %.2f%%", state.fedRate));
        }

        // next player
        state.currentPlayerIndex = (state.currentPlayerIndex + 1) % state.players.size();
        state.turnNumber++;

        UiHud.refreshTopHud(state);
        UiHud.refreshPlayersRow(state);
        if (state.boardPanel != null) state.boardPanel.repaint();
    }
}
