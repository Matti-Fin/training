package investor;

import java.util.ArrayList;
import java.util.List;

class BuildOption {
    public final String label;
    public final long cost;
    public final Runnable apply;

    BuildOption(String label, long cost, Runnable apply) {
        this.label = label;
        this.cost = cost;
        this.apply = apply;
    }
}

abstract class Property {

    public final String name;

    public final long lotPrice;

    public final long build1Cost;
    public final long build2Cost;

    public final long rate0;
    public final long rate1;
    public final long rate2;

    public final long basePopulationIncomePerRound;

    public int ownerIndex = -1;
    protected int stage = 0; // 0,1,2

    protected long investedExtra = 0;

    private int nightsThisRound = 0;
    private int lastRoundNights = 0;

    protected Property(
            String name,
            long lotPrice,
            long build1Cost,
            long build2Cost,
            long rate0,
            long rate1,
            long rate2,
            long basePopulationIncomePerRound
    ) {
        this.name = name;
        this.lotPrice = lotPrice;
        this.build1Cost = build1Cost;
        this.build2Cost = build2Cost;
        this.rate0 = rate0;
        this.rate1 = rate1;
        this.rate2 = rate2;
        this.basePopulationIncomePerRound = basePopulationIncomePerRound;
    }

    public boolean isOwned() { return ownerIndex >= 0; }

    public long currentNightRate() {
        return switch (stage) {
            case 0 -> rate0;
            case 1 -> rate1;
            default -> rate2;
        };
    }

    public long totalInvestedValue() {
        return lotPrice + investedExtra;
    }

    public void addPlayerNights(int n) {
        nightsThisRound += Math.max(0, n);
    }

    public int lastRoundNights() { return lastRoundNights; }

    public void rolloverRoundNights() {
        lastRoundNights = nightsThisRound;
        nightsThisRound = 0;
    }

    public String buildInfo() {
        String[] names = stageNames();
        int s = Math.max(0, Math.min(stage, names.length - 1));
        return names[s];
    }

    protected abstract String[] stageNames();

    public List<BuildOption> buildOptions() {
        List<BuildOption> out = new ArrayList<>();

        if (stage == 0 && build1Cost > 0) {
            out.add(new BuildOption(stageNames()[1], build1Cost, () -> {
                stage = 1;
                investedExtra += build1Cost;
            }));
        } else if (stage == 1 && build2Cost > 0) {
            out.add(new BuildOption(stageNames()[2], build2Cost, () -> {
                stage = 2;
                investedExtra += build2Cost;
            }));
        }

        return out;
    }

    public void onRoundTick(GameState state) {
        if (state == null) return;
        if (!isOwned()) return;

        double factor = Market.populationFactorFromNights(lastRoundNights(), state.players.size());
        long income = Math.round(basePopulationIncomePerRound * factor);

        if (income <= 0) return;

        Player owner = state.players.get(ownerIndex);
        owner.cash += income;
        owner.roundEarnings += income;
    }
}

class Hotel extends Property {
    public Hotel(
            String name,
            long lotPrice,
            long build1Cost,
            long build2Cost,
            long rate0,
            long rate1,
            long rate2,
            long basePopulationIncomePerRound
    ) {
        super(name, lotPrice, build1Cost, build2Cost, rate0, rate1, rate2, basePopulationIncomePerRound);
    }

    @Override
    protected String[] stageNames() {
        return new String[]{"Vanha hotelli", "Remontoitu hotelli", "Luksusmökit rakennettu"};
    }
}

class Restaurant extends Property {
    public Restaurant(
            String name,
            long lotPrice,
            long build1Cost,
            long build2Cost,
            long rate0,
            long rate1,
            long rate2,
            long basePopulationIncomePerRound
    ) {
        super(name, lotPrice, build1Cost, build2Cost, rate0, rate1, rate2, basePopulationIncomePerRound);
    }

    @Override
    protected String[] stageNames() {
        return new String[]{"Snägäri", "Ketjuravintola", "Fine dining"};
    }
}
