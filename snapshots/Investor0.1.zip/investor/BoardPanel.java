package investor;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.File;
import java.util.*;
import java.util.List;

public class BoardPanel extends JPanel implements MouseListener {

    // ---- NEW: manual grid masking (ONLY VISUAL) ----
    private final List<Rectangle> removedCells = new ArrayList<>();
    private final List<Rectangle> whiteBorderRects = new ArrayList<>();
    private final List<Rectangle> airportGateRects = new ArrayList<>();

    private final GameState state;

    // ---- legacy: bounds from Squares (kept, but no longer used for full-image grid) ----
    private int minGX, maxGX, minGY, maxGY;

    // Background image (optional)
    private BufferedImage backgroundImage;

    // Debug overlay toggle (later: false for players)
    private boolean showGridOverlay = true;

    // If true => show whole image (contain). If false => cover (crop).
    private boolean backgroundContain = true;

    // Padding around whole board area inside panel
    private static final int PADDING = 24;

    // ---- NEW: full-image grid (covers whole image rect) ----
    // Change these to make tiles smaller/bigger.
    // Good starts: 120x68 or 160x90.
    private int gridCols = 480;
    private int gridRows = 272;

    // Cached rect where background is drawn (contains/cover)
    private Rectangle bgRect = new Rectangle(0, 0, 1, 1);

    public BoardPanel(GameState state) {
        this.state = state;
        setBackground(new Color(245, 248, 252));
        computeBounds();
        addMouseListener(this);
        loadBackground();
        initManualZones();
    }

    // kept for legacy square grid (ownership tint etc.)
    public void computeBounds() {
        minGX = Integer.MAX_VALUE; maxGX = Integer.MIN_VALUE;
        minGY = Integer.MAX_VALUE; maxGY = Integer.MIN_VALUE;

        List<Square> all = new ArrayList<>(state.path);
        all.addAll(state.infoSquares);

        for (Square s : all) {
            minGX = Math.min(minGX, s.gx); maxGX = Math.max(maxGX, s.gx);
            minGY = Math.min(minGY, s.gy); maxGY = Math.max(maxGY, s.gy);
        }

        if (minGX == Integer.MAX_VALUE) { minGX = 0; maxGX = 0; minGY = 0; maxGY = 0; }
    }

    private void loadBackground() {
        String[] candidates = {
                "sfx/board_bg.png",
                "sfx/board_bg.jpg",
                "sfx/board_bg.jpeg"
        };

        for (String path : candidates) {
            try {
                File f = new File(path);
                if (f.exists()) {
                    backgroundImage = ImageIO.read(f);
                    return;
                }
            } catch (Exception ignored) {}
        }
    }

    /**
     * Rect inside panel where board content is allowed (padding on all sides).
     */
    private Rectangle getAvailRect() {
        int availW = Math.max(20, getWidth() - (PADDING * 2));
        int availH = Math.max(20, getHeight() - (PADDING * 2));
        return new Rectangle(PADDING, PADDING, availW, availH);
    }

    /**
     * Background rect:
     * - contain: whole image visible, may letterbox
     * - cover: fills rect, may crop
     */
    private Rectangle computeBackgroundRect() {
        Rectangle ar = getAvailRect();

        if (backgroundImage == null) {
            return new Rectangle(ar.x, ar.y, ar.width, ar.height);
        }

        int imgW = backgroundImage.getWidth();
        int imgH = backgroundImage.getHeight();
        if (imgW <= 0 || imgH <= 0) {
            return new Rectangle(ar.x, ar.y, ar.width, ar.height);
        }

        double scale;
        if (backgroundContain) {
            // CONTAIN (no crop)
            scale = Math.min((double) ar.width / imgW, (double) ar.height / imgH);
        } else {
            // COVER (crop)
            scale = Math.max((double) ar.width / imgW, (double) ar.height / imgH);
        }

        int drawW = (int) Math.round(imgW * scale);
        int drawH = (int) Math.round(imgH * scale);

        int dx = ar.x + (ar.width  - drawW) / 2;
        int dy = ar.y + (ar.height - drawH) / 2;

        return new Rectangle(dx, dy, drawW, drawH);
    }

    // 0->A, 25->Z, 26->AA, ...
    private String toExcelCol(int idx) {
        StringBuilder sb = new StringBuilder();
        int n = idx;
        while (n >= 0) {
            int r = n % 26;
            sb.append((char)('A' + r));
            n = (n / 26) - 1;
        }
        return sb.reverse().toString();
    }
    private int col(String excel) {
        int n = 0;
        for (int i = 0; i < excel.length(); i++) {
            n = n * 26 + (excel.charAt(i) - 'A' + 1);
    }
    return n - 1;
}

    // ruutujen merkkaus
    private void initManualZones() {

    // START ruutu: HA–IU, rivit 184–189
    removedCells.add(new Rectangle(
            col("HA"),      // sarake
            183,            // rivi 184 (0-based)
            col("IU") - col("HA") + 1,
            6               // 184–189
    ));

    // STARTin valkoiset reunat
    whiteBorderRects.add(new Rectangle(col("HA") - 1, 0, 1, gridRows));
    whiteBorderRects.add(new Rectangle(col("IU") + 1, 0, 1, gridRows));

    // Lentokenttäruutu: FP–GG, rivit 183–185
    removedCells.add(new Rectangle(
            col("FP"),
            182,            // rivi 183
            col("GG") - col("FP") + 1,
            3               // 183–185
    ));

    // Lentokentän portit
    airportGateRects.add(new Rectangle(col("FP"), 184, 1, 2)); // FP 185–186
    airportGateRects.add(new Rectangle(col("FQ"), 184, 1, 2));
    airportGateRects.add(new Rectangle(col("FR"), 185, 1, 2));
    airportGateRects.add(new Rectangle(col("FS"), 185, 1, 2));
    airportGateRects.add(new Rectangle(col("FT"), 185, 1, 2));
    airportGateRects.add(new Rectangle(col("FU"), 185, 1, 2));

    airportGateRects.add(new Rectangle(col("FV"), 185, 3, 2)); // FV–FX 186–187
    airportGateRects.add(new Rectangle(col("GA"), 186, 7, 2)); // GA–GG 187–188

    // Lentokentän valkoiset reunat
    whiteBorderRects.add(new Rectangle(col("FO"), 0, 1, gridRows));
    whiteBorderRects.add(new Rectangle(col("GI"), 0, 1, gridRows));
}
    

    //PIIRTO METODI
    private void drawManualZones(Graphics2D g2) {
    double cw = (double) bgRect.width / gridCols;
    double ch = (double) bgRect.height / gridRows;

    // piilotetut ruudut
    g2.setColor(getBackground());
    for (Rectangle r : removedCells) {
        g2.fillRect(
                (int)(bgRect.x + r.x * cw),
                (int)(bgRect.y + r.y * ch),
                (int)(r.width * cw),
                (int)(r.height * ch)
        );
    }

    // lentokentän portit
    g2.setColor(new Color(255, 200, 120, 180));
    for (Rectangle r : airportGateRects) {
        g2.fillRect(
                (int)(bgRect.x + r.x * cw),
                (int)(bgRect.y + r.y * ch),
                (int)(r.width * cw),
                (int)(r.height * ch)
        );
    }

    // valkoiset reunaviivat
    g2.setColor(Color.WHITE);
    for (Rectangle r : whiteBorderRects) {
        g2.fillRect(
                (int)(bgRect.x + r.x * cw),
                bgRect.y,
                (int)(r.width * cw),
                bgRect.height
        );
    }
}





    private String gridCoordString(int gx, int gy) {
        // gx,gy are 0-based indices in full image grid
        return toExcelCol(gx) + (gy + 1);
    }

    // ---------------------------------------------------------------------
    // Drawing
    // ---------------------------------------------------------------------
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // 1) background
        bgRect = computeBackgroundRect();
        if (backgroundImage != null) {
            g2.drawImage(backgroundImage, bgRect.x, bgRect.y, bgRect.width, bgRect.height, null);
        }
        
        // AINA taustan jälkeen
        drawManualZones(g2);

        // 2) FULL image grid overlay (the one you map road tiles with)
        if (showGridOverlay) {
            drawFullGrid(g2);
        }

        // 3) Legacy square overlays (kept so game still works now)
        //    NOTE: these still use old gx/gy from Square list and will appear “somewhere” on top.
        //    Later we will replace movement/path to use the full-image grid instead.
        for (Square s : state.infoSquares) drawSquareLegacy(g2, s);
        for (Square s : state.path)       drawSquareLegacy(g2, s);
        drawPlayersLegacy(g2);

        g2.dispose();
    }

    private void drawFullGrid(Graphics2D g2) {
        int cols = Math.max(1, gridCols);
        int rows = Math.max(1, gridRows);

        double cellW = (double) bgRect.width / cols;
        double cellH = (double) bgRect.height / rows;

        // grid lines
        g2.setColor(new Color(40, 40, 50, 110));
        for (int c = 0; c <= cols; c++) {
            int x = (int) Math.round(bgRect.x + c * cellW);
            g2.drawLine(x, bgRect.y, x, bgRect.y + bgRect.height);
        }
        for (int r = 0; r <= rows; r++) {
            int y = (int) Math.round(bgRect.y + r * cellH);
            g2.drawLine(bgRect.x, y, bgRect.x + bgRect.width, y);
        }

        // labels (harvennettu ettei mene mössöksi)
        g2.setFont(new Font("Monospaced", Font.BOLD, 12));
        g2.setColor(new Color(20, 20, 25, 170));

        int stepX = Math.max(1, cols / 16);
        int stepY = Math.max(1, rows / 10);

        for (int c = 0; c < cols; c += stepX) {
            int x = (int) Math.round(bgRect.x + c * cellW) + 3;
            g2.drawString(toExcelCol(c), x, bgRect.y + 14);
        }
        for (int r = 0; r < rows; r += stepY) {
            int y = (int) Math.round(bgRect.y + r * cellH) + 14;
            g2.drawString("" + (r + 1), bgRect.x + 3, y);
        }
    }

    // ---------------------------------------------------------------------
    // Legacy square drawing (kept)
    // ---------------------------------------------------------------------

    private int colsLegacy() { return (maxGX - minGX + 1); }
    private int rowsLegacy() { return (maxGY - minGY + 1); }

    private int legacyTileSize() {
        int c = Math.max(1, colsLegacy());
        int r = Math.max(1, rowsLegacy());

        // fit legacy grid inside bgRect (so it's at least consistent)
        int availW = Math.max(50, bgRect.width);
        int availH = Math.max(50, bgRect.height);

        return Math.max(2, Math.min(availW / c, availH / r));
    }

    private Point legacyGridToPixelTopLeft(int gx, int gy) {
        int tile = legacyTileSize();
        int c = colsLegacy();
        int r = rowsLegacy();

        int gridW = c * tile;
        int gridH = r * tile;

        int startX = bgRect.x + (bgRect.width  - gridW) / 2;
        int startY = bgRect.y + (bgRect.height - gridH) / 2;

        int px = startX + (gx - minGX) * tile;
        int py = startY + (gy - minGY) * tile;

        return new Point(px, py);
    }

    private String coordStringLegacy(int gx, int gy) {
        String col = toExcelCol(gx - minGX);
        int row = (gy - minGY + 1);
        return col + row;
    }

    private void drawSquareLegacy(Graphics2D g2, Square s) {
        int tile = legacyTileSize();
        Point p = legacyGridToPixelTopLeft(s.gx, s.gy);

        int w = (int) Math.round(tile * s.wScale);
        int h = (int) Math.round(tile * s.hScale);
        int px = p.x + (tile - w) / 2;
        int py = p.y + (tile - h) / 2;

        s.pixelRect = new Rectangle(px, py, w, h);

        int alpha = 150;
        Color base;

        if (s.type == SquareType.INFO_INSIDE || s.type == SquareType.INFO_OUTSIDE) {
            base = new Color(230, 236, 245, alpha);
        } else if (s.type == SquareType.START) {
            base = new Color(210, 240, 210, alpha);
        } else if (s.type == SquareType.SEAT) {
            base = new Color(220, 240, 255, alpha);
        } else if (s.type == SquareType.CHECKPOINT_THIN) {
            base = new Color(240, 240, 190, alpha);
        } else {
            base = ((s.gx + s.gy) % 2 == 0)
                    ? new Color(240, 217, 181, alpha)
                    : new Color(181, 136, 99, alpha);
        }

        base = applyOwnershipTint(base, s, alpha);

        g2.setColor(base);
        g2.fillRect(px, py, w, h);

        g2.setColor(new Color(40, 40, 50, 180));
        g2.drawRect(px, py, w, h);

        if (tile >= 12) {
            g2.setFont(new Font("SansSerif", Font.BOLD, 10));
            g2.setColor(new Color(60, 60, 70, 200));
            g2.drawString(coordStringLegacy(s.gx, s.gy), px + 4, py + 12);
        }

        if (tile >= 18) {
            String label = (s.label == null) ? "" : s.label;
            g2.setFont(new Font("SansSerif", Font.BOLD, 11));
            g2.setColor(new Color(25, 25, 35, 220));
            drawCentered(g2, label, s.pixelRect);
        }
    }

    private Color applyOwnershipTint(Color base, Square s, int alpha) {
        try {
            if (s.type == SquareType.LOT && s.property != null && s.property.ownerIndex != -1) {
                Color pc = state.players.get(s.property.ownerIndex).color;
                return new Color(pc.getRed(), pc.getGreen(), pc.getBlue(), alpha);
            }

            if (s.type == SquareType.SEAT && s.seat != null && s.seat.ownerIndex != -1) {
                Color pc = state.players.get(s.seat.ownerIndex).color;
                return new Color(pc.getRed(), pc.getGreen(), pc.getBlue(), alpha);
            }

            if (s.type == SquareType.GATE && s.gateGroup != null && s.gateGroup.ownerIndex != -1) {
                Color pc = state.players.get(s.gateGroup.ownerIndex).color;
                return new Color(pc.getRed(), pc.getGreen(), pc.getBlue(), alpha);
            }

            if (s.type == SquareType.DUAL_LOT) {
                int cur = state.currentPlayerIndex;

                int inOwner  = (s.insideProperty  != null) ? s.insideProperty.ownerIndex  : -1;
                int outOwner = (s.outsideProperty != null) ? s.outsideProperty.ownerIndex : -1;

                int useOwner = -1;
                if (inOwner == cur) useOwner = inOwner;
                else if (outOwner == cur) useOwner = outOwner;
                else if (inOwner != -1) useOwner = inOwner;
                else if (outOwner != -1) useOwner = outOwner;

                if (useOwner != -1) {
                    Color pc = state.players.get(useOwner).color;
                    return new Color(pc.getRed(), pc.getGreen(), pc.getBlue(), alpha);
                }
            }
        } catch (Exception ignored) {}

        return base;
    }

    private void drawPlayersLegacy(Graphics2D g2) {
        int tile = legacyTileSize();

        Map<Integer, List<Integer>> onSquare = new HashMap<>();
        for (int i = 0; i < state.players.size(); i++) {
            onSquare.computeIfAbsent(state.players.get(i).posId, k -> new ArrayList<>()).add(i);
        }

        for (Map.Entry<Integer, List<Integer>> e : onSquare.entrySet()) {
            int sid = e.getKey();
            if (sid < 0 || sid >= state.path.size()) continue;

            Square s = state.path.get(sid);
            if (s.pixelRect == null) continue;

            int cx = s.pixelRect.x + s.pixelRect.width / 2;
            int cy = s.pixelRect.y + s.pixelRect.height / 2;

            List<Integer> idxs = e.getValue();
            for (int k = 0; k < idxs.size(); k++) {
                int pi = idxs.get(k);
                Player pl = state.players.get(pi);

                int ox = (k % 2 == 0) ? -tile / 5 : tile / 5;
                int oy = (k / 2) * (tile / 6) - 5;

                drawCone(g2, cx + ox, cy + oy, Math.max(4, tile / 4), pl.color, pi == state.currentPlayerIndex);
            }
        }
    }

    private void drawCone(Graphics2D g2, int cx, int cy, int size, Color fill, boolean isCurrent) {
        int half = size / 2;
        Polygon tri = new Polygon(
                new int[]{cx - half, cx + half, cx},
                new int[]{cy + half, cy + half, cy - half},
                3
        );
        g2.setColor(fill);
        g2.fillPolygon(tri);

        g2.setStroke(new BasicStroke(isCurrent ? 3f : 1f));
        g2.setColor(Color.BLACK);
        g2.drawPolygon(tri);
        g2.setStroke(new BasicStroke(1f));
    }

    private void drawCentered(Graphics2D g2, String txt, Rectangle r) {
        if (txt == null) txt = "";
        FontMetrics fm = g2.getFontMetrics();
        int x = r.x + (r.width - fm.stringWidth(txt)) / 2;
        int y = r.y + (r.height + fm.getAscent()) / 2 - 2;
        g2.drawString(txt, x, y);
    }

    // ---------------------------------------------------------------------
    // Click: prints FULL-IMAGE GRID coordinate under mouse (this is what you use to map the road)
    // ---------------------------------------------------------------------
    @Override
    public void mouseClicked(MouseEvent e) {
        if (!showGridOverlay) return;

        int mx = e.getX();
        int my = e.getY();

        if (!bgRect.contains(mx, my)) return;

        int cols = Math.max(1, gridCols);
        int rows = Math.max(1, gridRows);

        double cellW = (double) bgRect.width / cols;
        double cellH = (double) bgRect.height / rows;

        int gx = (int) ((mx - bgRect.x) / cellW); // 0..cols-1
        int gy = (int) ((my - bgRect.y) / cellH); // 0..rows-1

        gx = Math.max(0, Math.min(cols - 1, gx));
        gy = Math.max(0, Math.min(rows - 1, gy));

        String coord = gridCoordString(gx, gy);

        System.out.println("CLICK grid=" + coord + " (gx=" + gx + " gy=" + gy + ")");
        if (state != null && state.infoLabel != null) {
            state.infoLabel.setText("Click: " + coord + " (gx=" + gx + ", gy=" + gy + ")");
        }
    }

    @Override public void mousePressed(MouseEvent e) { }
    @Override public void mouseReleased(MouseEvent e) { }
    @Override public void mouseEntered(MouseEvent e) { }
    @Override public void mouseExited(MouseEvent e) { }
}
