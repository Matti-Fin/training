package investor;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class Player {

    public final String name;
    public final Color color;

    public long cash;
    public long debt = 0;

    // Bonds (placeholder – later we add real logic)
    public long bondsLT1 = 0;
    public long bondsLT2 = 0;
    public long bondsGT2 = 0;


    public int posId = 0;

    public final List<Property> owned = new ArrayList<>();

    // round tracking
    public long roundEarnings = 0;

    // risk (base + casino extra)
    public int riskMarginPct = 0;
    public int casinoRiskExtraPct = 0;

    public Player(String name, Color color, long startCash) {
        this.name = name;
        this.color = color;
        this.cash = startCash;
    }

    public int totalRiskMarginPct() {
        return Math.max(0, riskMarginPct + casinoRiskExtraPct);
    }

    public long netWorth() {
        long v = cash - debt;
        for (Property p : owned) v += p.totalInvestedValue();
        return v;
    }
    public long propertiesValue() {
        long v = 0;
        for (Property p : owned) {
            if (p != null) v += p.lotPrice; // simple placeholder
        }
        return v;
    }

}
