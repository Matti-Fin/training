package investor;

import java.awt.Point;
import java.util.*;

public class BoardFactory {

    static final int GRID_W = 8;
    static final int GRID_H = 6;

    static List<Point> buildPerimeterPathPoints() {
        int startX = GRID_W / 2;
        int startY = 0;

        List<Point> pts = new ArrayList<>();
        Set<String> seen = new HashSet<>();

        int x = startX, y = startY;

        java.util.function.BiConsumer<Integer, Integer> add = (xx, yy) -> {
            String key = xx + "," + yy;
            if (!seen.contains(key)) {
                pts.add(new Point(xx, yy));
                seen.add(key);
            }
        };

        add.accept(x, y);

        while (x > 0) { x--; add.accept(x, y); }
        while (y < GRID_H - 1) { y++; add.accept(x, y); }
        while (x < GRID_W - 1) { x++; add.accept(x, y); }
        while (y > 0) { y--; add.accept(x, y); }
        while (x > startX) { x--; add.accept(x, y); }

        return pts;
    }

    static void computeEntrySides(List<Square> path) {
        for (int i = 1; i < path.size(); i++) {
            Square prev = path.get(i - 1);
            Square cur  = path.get(i);
            int dx = cur.gx - prev.gx;
            int dy = cur.gy - prev.gy;

            if (dx == 1) cur.entrySide = EntrySide.LEFT;
            else if (dx == -1) cur.entrySide = EntrySide.RIGHT;
            else if (dy == 1) cur.entrySide = EntrySide.BOTTOM;
            else if (dy == -1) cur.entrySide = EntrySide.TOP;
            else cur.entrySide = EntrySide.NONE;
        }
    }

    static void buildBoard(GameState state) {
        List<Point> pts = buildPerimeterPathPoints();

        state.path.clear();
        state.infoSquares.clear();
        state.allProperties.clear();

        for (int i = 0; i < pts.size(); i++) {
            Point p = pts.get(i);
            state.path.add(new Square(i, p.x, p.y, SquareType.EMPTY, ""));
        }

        // START
        state.path.get(0).type = SquareType.START;
        state.path.get(0).label = "START";

        // CHECKPOINT thin tile
        state.path.get(1).type = SquareType.CHECKPOINT_THIN;
        state.path.get(1).label = "";
        state.path.get(1).scale(0.25, 1.0);

        // INFO squares (off-path) near checkpoint
        Square cp = state.path.get(1);
        Square verottaja = new Square(10_001, cp.gx, cp.gy + 1, SquareType.INFO_INSIDE, "Verottaja");
        Square kela      = new Square(10_002, cp.gx, cp.gy - 1, SquareType.INFO_OUTSIDE, "KELA");
        state.infoSquares.add(verottaja);
        state.infoSquares.add(kela);

        // Square #2 = DUAL_LOT (inside hotel / outside restaurant)
        if (state.path.size() > 2) {
            Square s2 = state.path.get(2);
            s2.type = SquareType.DUAL_LOT;
            s2.label = "DUAL";

            Hotel insideHotel = new Hotel(
                    "Hotel Aurora (Inside)",
                    300_000,
                    200_000,
                    400_000,
                    5_000,
                    7_500,
                    10_000,
                    5_000
            );

            Restaurant outsideRestaurant = new Restaurant(
                    "Ravintola Ranta (Outside)",
                    100_000,
                    80_000,
                    160_000,
                    1_000,
                    2_000,
                    5_000,
                    1_500
            );

            s2.insideProperty = insideHotel;
            s2.outsideProperty = outsideRestaurant;

            state.allProperties.add(insideHotel);
            state.allProperties.add(outsideRestaurant);
        }

        // Gate: two tiles (3 and 4) share same GateGroup
        if (state.path.size() > 4) {
            GateGroup gateTo2 = new GateGroup("Gate to #2");

            Square g1 = state.path.get(3);
            g1.type = SquareType.GATE;
            g1.label = "GATE";
            g1.gateGroup = gateTo2;

            Square g2 = state.path.get(4);
            g2.type = SquareType.GATE;
            g2.label = "GATE";
            g2.gateGroup = gateTo2;
        }

        // Optional: casino somewhere later
        if (state.path.size() > 8) {
            state.path.get(8).type = SquareType.CASINO;
            state.path.get(8).label = "CASINO";
        }

        computeEntrySides(state.path);
    }
}
