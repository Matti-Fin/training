package investor;

import javax.swing.*;

public class Investor {

    public static void main(String[] args) {

        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Investor");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(1100, 780);
            frame.setLocationRelativeTo(null);

            GameState state = new GameState();

            // defaults (voit säätää myöhemmin valikkoon)
            state.cfg.startCash = 1_000_000;           // default start cash
            state.cfg.kelaWealthThreshold = 1_000_000; // below this -> eligible
            state.cfg.kelaSupportPerRound = 20_000;
            state.cfg.seatPrice = 1_000;              // placeholder

            // ask setup
            SettingsDialogs.SetupResult setup = SettingsDialogs.showSetupDialog(frame, state);
            if (setup == null) {
                frame.dispose();
                return;
            }
            state.players = setup.players;

            // build board
            BoardFactory.buildBoard(state);

            // Board panel
            state.boardPanel = new BoardPanel(state);

            // HUD overlay (piirtyy boardin päälle)
            JPanel overlayHud = UiHud.buildOverlayHud(state);

            // Layered: board alimmaksi, HUD päälle
            JLayeredPane layered = new JLayeredPane();
            layered.setLayout(null);

            layered.add(state.boardPanel, JLayeredPane.DEFAULT_LAYER);
            layered.add(overlayHud, JLayeredPane.PALETTE_LAYER);

            frame.setContentPane(layered);

            // pidetään komponentit koko ikkunan kokoisina
            frame.addComponentListener(new java.awt.event.ComponentAdapter() {
                @Override public void componentResized(java.awt.event.ComponentEvent e) {
                    int w = frame.getContentPane().getWidth();
                    int h = frame.getContentPane().getHeight();

                    state.boardPanel.setBounds(0, 0, w, h);
                    overlayHud.setBounds(0, 0, w, h);

                    UiHud.positionOverlay(state);
                    state.boardPanel.repaint();
                }
            });

            // näytetään UI
            frame.setVisible(true);

            // initial bounds + overlay layout (kun frame on näkyvissä)
            SwingUtilities.invokeLater(() -> {
                int w = frame.getContentPane().getWidth();
                int h = frame.getContentPane().getHeight();

                state.boardPanel.setBounds(0, 0, w, h);
                overlayHud.setBounds(0, 0, w, h);

                UiHud.positionOverlay(state);
                UiHud.refreshAll(state);
            });

            // käynnistä taustamusiikki jos äänet päällä
            if (state.soundOn) {
                Audio.startBgmRandom(state, 0.25f);
            }
        });
    }
}
