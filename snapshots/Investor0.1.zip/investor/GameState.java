package investor;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class GameState {

    public final Config cfg = new Config();

    public List<Player> players = new ArrayList<>();

    public final List<Square> path = new ArrayList<>();
    public final List<Square> infoSquares = new ArrayList<>();
    public final List<Property> allProperties = new ArrayList<>();

    public int currentPlayerIndex = 0;
    public int turnNumber = 1;
    public int lastRoll = 0;

    // market / FED
    public double fedRate = 5.0;
    public boolean fedRateJustChanged = false;

    // turn metrics (Finance increments)
    public int _investmentsThisTurn = 0;
    public int _nightsThisTurn = 0;

    // SFX throttling
    public long _lastFootstepMs = 0;

    // Sound toggle
    public boolean soundOn = true;

    // UI references (set by UI code)
    public JButton rollBtn;
    public JLabel diceLabel;
    public JLabel infoLabel;
    public JLabel marketLabel;


    public BoardPanel boardPanel;

    // optional HUD containers (UiHud may populate)
    public JPanel hudTop;
    public JPanel playersRow;

    public boolean isBusy = false;

    public Player currentPlayer() {
        if (players == null || players.isEmpty()) return null;
        return players.get(currentPlayerIndex);
    }
}
