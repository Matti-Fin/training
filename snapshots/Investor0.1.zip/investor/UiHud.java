package investor;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.List;

public class UiHud {

    // ---------- overlay layout tuning ----------
    private static final int MARGIN = 14;

    // alavasen "jonolista" (kompaktit pelaajat)
    private static final int STRIP_HEIGHT = 86;
    private static final int STRIP_MAX_WIDTH = 620;
    private static final int STRIP_MIN_WIDTH = 380;

    // alaoikea "aktiivinen pelaaja" iso kortti
    private static final int ACTIVE_W = 420;
    private static final int ACTIVE_H = 220;

    // ---------- keep references ----------
    private static JPanel overlayRoot;
    private static JPanel stripPanel;
    private static ActivePlayerPanel activePanel;
    private static final List<CompactPlayerPanel> compactPanels = new ArrayList<>();

    /**
     * Tämä rakennetaan JLayeredPane overlayksi: EI vie tilaa ikkunasta (piirtyy BoardPanelin päälle).
     */
    public static JPanel buildOverlayHud(GameState state) {
        overlayRoot = new JPanel(null);
        overlayRoot.setOpaque(false);

        // --- alavasen: kompaktit pelaajat vuorojärjestyksessä ---
        stripPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        stripPanel.setOpaque(true);
        stripPanel.setBackground(new Color(255, 255, 255, 210));
        stripPanel.setBorder(BorderFactory.createLineBorder(new Color(30, 30, 40, 140), 1));

        // build compact panels (instances once)
        compactPanels.clear();
        stripPanel.removeAll();
        for (int i = 0; i < state.players.size(); i++) {
            CompactPlayerPanel cp = new CompactPlayerPanel(state, i);
            compactPanels.add(cp);
            stripPanel.add(cp);
        }

        // --- alaoikea: aktiivinen pelaaja iso kortti + nappulat + info ---
        activePanel = new ActivePlayerPanel(state);
        activePanel.setOpaque(true);
        activePanel.setBackground(new Color(255, 255, 255, 235));
        activePanel.setBorder(BorderFactory.createLineBorder(new Color(30, 30, 40, 160), 2));

        overlayRoot.add(stripPanel);
        overlayRoot.add(activePanel);

        // sijoitellaan heti
        positionOverlay(state);

        // ja uudelleensijoitus kun overlayRootin koko muuttuu (ikkunan resize)
        overlayRoot.addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) {
                positionOverlay(state);
            }
        });

        refreshAll(state);
        return overlayRoot;
    }

    /**
     * Kutsutaan Investor.javasta kun layered-pane resizaa (tai tästä sisäisesti).
     */
    public static void positionOverlay(GameState state) {
        if (overlayRoot == null || stripPanel == null || activePanel == null) return;

        int w = overlayRoot.getWidth();
        int h = overlayRoot.getHeight();
        if (w <= 0 || h <= 0) return;

        // aktiivikortti alaoikeaan
        int ax = Math.max(MARGIN, w - ACTIVE_W - MARGIN);
        int ay = Math.max(MARGIN, h - ACTIVE_H - MARGIN);
        activePanel.setBounds(ax, ay, ACTIVE_W, ACTIVE_H);

        // strip alavasen: jätä tilaa activePanelille
        int stripW = ax - (MARGIN * 2);
        stripW = Math.max(STRIP_MIN_WIDTH, Math.min(stripW, STRIP_MAX_WIDTH));
        int sx = MARGIN;
        int sy = h - STRIP_HEIGHT - MARGIN;
        stripPanel.setBounds(sx, sy, stripW, STRIP_HEIGHT);
    }

    public static void refreshAll(GameState state) {
        refreshTopHud(state);
        refreshPlayersRow(state);
    }

    /**
     * Päivittää FED/dice/turn/info aktiivikortissa.
     */
    public static void refreshTopHud(GameState state) {
        if (state.marketLabel != null) {
            state.marketLabel.setText(String.format("FED: %.2f%%", state.fedRate));
        }
        if (state.infoLabel != null) {
            String cur = state.infoLabel.getText();
            if (cur == null || cur.isBlank() || cur.startsWith("Turn:")) {
                Player pl = state.currentPlayer();
                state.infoLabel.setText("Turn: " + pl.name);
            }
        }
        if (activePanel != null) activePanel.refresh();
    }

    /**
     * Päivittää kompaktit listat + aktiivikortti.
     */
    public static void refreshPlayersRow(GameState state) {
        if (stripPanel != null) {
            for (CompactPlayerPanel cp : compactPanels) cp.refresh(false);

            for (CompactPlayerPanel cp : compactPanels) {
                boolean isCurrent = (cp.playerIndex == state.currentPlayerIndex);
                cp.refresh(isCurrent);
            }
        }
        if (activePanel != null) activePanel.refresh();
    }

    // =====================================================================
    //  Compact player panel (alavasen strip)
    // =====================================================================
    static class CompactPlayerPanel extends JPanel {
        final GameState state;
        final int playerIndex;

        private final JLabel name = new JLabel();
        private final JLabel money = new JLabel();
        private final JLabel debt = new JLabel();
        private final JLabel net  = new JLabel();
        private final JLabel due  = new JLabel(); // placeholder

        CompactPlayerPanel(GameState state, int idx) {
            this.state = state;
            this.playerIndex = idx;

            setOpaque(false);
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setBorder(new EmptyBorder(2, 6, 2, 6));
            setPreferredSize(new Dimension(180, 66));

            name.setFont(new Font("SansSerif", Font.BOLD, 12));
            money.setFont(new Font("SansSerif", Font.PLAIN, 11));
            debt.setFont(new Font("SansSerif", Font.PLAIN, 11));
            net.setFont(new Font("SansSerif", Font.PLAIN, 11));
            due.setFont(new Font("SansSerif", Font.PLAIN, 11));
            due.setForeground(new Color(90, 90, 105));

            add(name);
            add(money);
            add(debt);
            add(net);
            add(due);

            refresh(false);
        }

        void refresh(boolean isCurrent) {
            Player p = state.players.get(playerIndex);

            name.setText(p.name);
            money.setText("Cash: $" + fmt(p.cash));
            debt.setText("Debt: $" + fmt(p.debt));
            net.setText("Net: $" + fmt(p.netWorth()));

            //TODO: kun lyhennyslogiikka lisätään, vaihdetaan tähän oikea arvo
            due.setText("Due (this round): $" + fmt(0));

            if (isCurrent) {
                name.setForeground(new Color(20, 20, 25));
                setBackground(new Color(230, 245, 235, 220));
                setOpaque(true);
            } else {
                name.setForeground(new Color(30, 30, 40));
                setOpaque(false);
            }
        }

        private String fmt(long v) { return String.format("%,d", v); }
    }

    // =====================================================================
    //  Active player panel (alaoikea iso kortti)
    // =====================================================================
    static class ActivePlayerPanel extends JPanel {
        final GameState state;

        private final JLabel title = new JLabel();
        private final JLabel cash  = new JLabel();
        private final JLabel debt  = new JLabel();
        private final JLabel net   = new JLabel();
        private final JLabel risk  = new JLabel();
        private final JLabel props = new JLabel();
        private final JLabel bonds = new JLabel();

        private final JTextArea ownedList = new JTextArea();
        private final JScrollPane ownedScroll = new JScrollPane(ownedList);

        private final JPanel topRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        private final JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 6));

        private final JButton soundBtn = new JButton("🔊");

        ActivePlayerPanel(GameState state) {
            this.state = state;
            setLayout(new BorderLayout());

            // --- top: title + dice + fed ---
            topRow.setOpaque(false);

            title.setFont(new Font("SansSerif", Font.BOLD, 14));
            topRow.add(title);

            if (state.diceLabel == null) {
                state.diceLabel = new JLabel("🎲");
                state.diceLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
            }
            topRow.add(state.diceLabel);

            if (state.marketLabel == null) {
                state.marketLabel = new JLabel(String.format("FED: %.2f%%", state.fedRate));
                state.marketLabel.setFont(new Font("SansSerif", Font.PLAIN, 14));
            }
            topRow.add(state.marketLabel);

            add(topRow, BorderLayout.NORTH);

            // --- center: left stats + right owned scroll ---
            JPanel center = new JPanel(new GridLayout(1, 2, 10, 0));
            center.setOpaque(false);
            center.setBorder(new EmptyBorder(6, 10, 6, 10));

            JPanel left = new JPanel();
            left.setOpaque(false);
            left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));

            setSmall(cash); setSmall(debt); setSmall(net); setSmall(risk);
            setSmall(props); setSmall(bonds);

            left.add(cash);
            left.add(debt);
            left.add(net);
            left.add(risk);
            left.add(Box.createVerticalStrut(6));
            left.add(props);
            left.add(bonds);

            ownedList.setEditable(false);
            ownedList.setLineWrap(true);
            ownedList.setWrapStyleWord(true);
            ownedList.setFont(new Font("SansSerif", Font.PLAIN, 12));
            ownedList.setBackground(new Color(250, 250, 252));
            ownedList.setBorder(new EmptyBorder(6, 6, 6, 6));
            ownedScroll.setBorder(BorderFactory.createLineBorder(new Color(220, 225, 235)));

            center.add(left);
            center.add(ownedScroll);

            add(center, BorderLayout.CENTER);

            // --- bottom: info + roll + sound ---
            JPanel bottom = new JPanel(new BorderLayout());
            bottom.setOpaque(false);
            bottom.setBorder(new EmptyBorder(0, 10, 6, 10));

            if (state.infoLabel == null) state.infoLabel = new JLabel(" ");
            state.infoLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            bottom.add(state.infoLabel, BorderLayout.WEST);

            btnRow.setOpaque(false);

            // sound toggle
            soundBtn.setFocusPainted(false);
            soundBtn.addActionListener(e -> {
                state.soundOn = !state.soundOn;
                Audio.setEnabled(state.soundOn);

                soundBtn.setText(state.soundOn ? "🔊" : "🔇");
                soundBtn.setForeground(state.soundOn ? new Color(20,20,25) : new Color(180,40,40));

                if (state.soundOn) {
                    Audio.startBgmRandom(state, 0.25f);
                    if (state.infoLabel != null) state.infoLabel.setText("Sound ON");
                } else {
                    Audio.stopBgm();
                    if (state.infoLabel != null) state.infoLabel.setText("Sound OFF");
                }
            });
            soundBtn.setText(state.soundOn ? "🔊" : "🔇");
            soundBtn.setForeground(state.soundOn ? new Color(20,20,25) : new Color(180,40,40));

            // roll button
            if (state.rollBtn == null) state.rollBtn = new JButton("Roll");
            state.rollBtn.addActionListener(e -> {
                if (state.isBusy) return;

                TurnLogic.startTurn(state);

                Dice.rollDiceAnimated(state, roll -> {
                    Player pl = state.currentPlayer();
                    if (state.infoLabel != null) state.infoLabel.setText("Turn: " + pl.name + " | Rolled " + roll);

                    TurnLogic.movePlayerAnimated(state, roll, () -> TurnLogic.endTurn(state));
                });
            });

            btnRow.add(soundBtn);
            btnRow.add(state.rollBtn);

            bottom.add(btnRow, BorderLayout.EAST);
            add(bottom, BorderLayout.SOUTH);

            refresh();
        }

        private void setSmall(JLabel l) {
            l.setFont(new Font("SansSerif", Font.PLAIN, 12));
            l.setForeground(new Color(30, 30, 40));
        }

        void refresh() {
            Player p = state.currentPlayer();
            title.setText("ACTIVE: " + p.name);

            cash.setText("Cash: $" + fmt(p.cash));
            debt.setText("Debt: $" + fmt(p.debt));
            net.setText("Net: $" + fmt(p.netWorth()));

            int totalRisk = 0;
            try {
                totalRisk = p.riskMarginPct + p.casinoRiskExtraPct;
            } catch (Exception ignored) {}
            risk.setText("Risk margin: " + totalRisk + "%");

            long pv = 0;
            try { pv = p.propertiesValue(); } catch (Exception ignored) {}

            long bondsAll = 0;
            try { bondsAll = p.bondsLT1 + p.bondsLT2 + p.bondsGT2; } catch (Exception ignored) {}

            props.setText("Businesses: $" + fmt(pv));
            bonds.setText("Bonds: $" + fmt(bondsAll));

            ownedList.setText(buildOwnedText(p));

            if (state.marketLabel != null) {
                state.marketLabel.setText(String.format("FED: %.2f%%", state.fedRate));
            }
        }

        private String buildOwnedText(Player p) {
            StringBuilder sb = new StringBuilder();
            sb.append("Businesses:\n");
            if (p.owned == null || p.owned.isEmpty()) {
                sb.append(" - (none)\n");
                return sb.toString();
            }
            for (Property pr : p.owned) {
                if (pr == null) continue;
                sb.append(" - ").append(pr.name).append("\n");
            }
            return sb.toString();
        }

        private String fmt(long v) { return String.format("%,d", v); }
    }

    // ---------------------------------------------------------------------
    // (Optional) MouseListener import was present in your file; keeping it
    // harmless. No extra code needed here.
    // ---------------------------------------------------------------------
}
